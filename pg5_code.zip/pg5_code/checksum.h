#ifndef _CHECKSUM_H_
#define _CHECKSUM_H_

unsigned int checksum(unsigned short * data, int len);

#endif
